package com.example.vdaiproductapp.models

import com.google.gson.annotations.SerializedName

data class CartItemRequest(
    @SerializedName("productId") val productId: Int,
    @SerializedName("title") val title: String,
    @SerializedName("latitude") val latitude: Double,
    @SerializedName("longitude") val longitude: Double
)
