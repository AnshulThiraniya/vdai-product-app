package com.example.vdaiproductapp.activity

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.vdaiproductapp.R
import com.example.vdaiproductapp.adapters.ProductAdapter
import com.example.vdaiproductapp.databinding.ActivityMainBinding
import com.example.vdaiproductapp.viewmodel.ProductViewmodel

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var viewmodel:ProductViewmodel
    lateinit var myAdapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=DataBindingUtil.setContentView(this,R.layout.activity_main)

        viewmodel=ViewModelProvider(this)[ProductViewmodel::class.java]


        val progressDialog= ProgressDialog(this)
        progressDialog.setMessage("loading please wait...")
        progressDialog.setCancelable(false)

       viewmodel.ProductLoad.observe(this, Observer {
           if(it){
               progressDialog.show()
           }
           else
           {
               progressDialog.dismiss()
           }
       })

        viewmodel.getProduct().observe(this, Observer {
                myAdapter= ProductAdapter (this,it)
                binding.rvProductList.layoutManager= LinearLayoutManager(this)
                binding.rvProductList.adapter=myAdapter
                myAdapter.notifyDataSetChanged()

        })




      viewmodel.addCart().observe(this, Observer {

      })

    }
}